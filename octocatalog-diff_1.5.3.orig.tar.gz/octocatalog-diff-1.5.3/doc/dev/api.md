# octocatalog-diff API documentation

The octocatalog-diff API allows developers to construct and work with certain octocatalog-diff internals in their own projects.

The current API version is [API v1](/doc/dev/api/v1.md), which is available as of octocatalog-diff version 1.0.
